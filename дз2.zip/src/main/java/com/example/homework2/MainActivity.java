package com.example.homework2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String KEY = "KEY";

    TextView _sumAll;
    TextView _arithmeticMean;
    TextView _rezFun3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RandomNumber rn1 = new RandomNumber();
        ArrayList<Integer> array = rn1.getArrayRandomNumber();
        TextView text1=(TextView)findViewById(R.id.sumAll);
        TextView text2=(TextView)findViewById(R.id.arithmeticMean);
        TextView text3=(TextView)findViewById(R.id.rezFun3);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ActivityOne.class);

                intent.putIntegerArrayListExtra("ARRAY", array);
                startActivityForResult(intent, 1000);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1000 && resultCode == Activity.RESULT_OK && data != null) {
            int result1 = data.getIntExtra("R1", 0);
            TextView text1 = findViewById(R.id.sumAll);
            text1.setText("Сумма всех чисел\n равна: " + result1);
            double result2 = data.getDoubleExtra("R2", 0);
            TextView text2 = findViewById(R.id.arithmeticMean);
            text2.setText("Среднее арифметическое составляет: " + result2);
            double result3 = data.getDoubleExtra("R3", 0);
            TextView text3 = findViewById(R.id.rezFun3);
            text3.setText("Результат выполнения fun3 равен: " + result3);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}