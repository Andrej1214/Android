package com.example.homework2;

import java.time.Clock;
import java.util.ArrayList;

public class Counter {
    public int getSumAll(ArrayList<Integer> m) {
        int rez = 0;
        for (int i = 0; i < m.size();i++) {
            rez = rez + m.get(i);
        }
        return rez;
    }

    public double getArithmeticMean(ArrayList<Integer> m) {
        double rez1 = 0;
        for (int i = 0; i < m.size();i++) {
            rez1 = (rez1 + m.get(i));
        }
        double d;
        d = rez1 / m.size();
        return d;
    }

    public double getRezFun3(ArrayList<Integer> m) {
        double rez1 = 0;
        double rez2 = 0;
        double rez3 = 0;
        for (int i = 0, j = 1; i < m.size() && j < m.size(); i=i+2, j=j+2) {
            rez1 = rez1 + m.get(i);
            rez2 = rez2 + m.get(j);
        }
        rez3 = rez1 / rez2;

        return rez3;
    }
}
