package com.example.homework2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class RandomNumber {
    public int a;
    Set<Integer> sc = new HashSet<>();
    ArrayList<Integer> list1 = new ArrayList<>();

    public ArrayList<Integer> getArrayRandomNumber() {
        Random rd = new Random();
        a = 2 * rd.nextInt(12);
        int m = 0;
        while (m < a) {
            int b = rd.nextInt(50);
            sc.add(b);
            m++;
        }

        for (Object ob : sc) {
            list1.add((Integer) ob);
        }
        return list1;
    }
}
